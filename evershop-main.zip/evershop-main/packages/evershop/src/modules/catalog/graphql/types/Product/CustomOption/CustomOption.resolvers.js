module.exports = {
  Product: {
    options: async () => [] // TODO: To be implemented
  }
};
